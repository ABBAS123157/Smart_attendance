import io
import numpy as np
import pytest
from app import create_app, db, User, Student, AttendanceSession, Attendance

class FakeEngine:
    def embedding_from_bytes(self, raw):
        if raw == b"bad": raise ValueError("bad image")
        # deterministic fake embedding for API tests; NOT a recognition model
        return np.array([1.0, 0.0, 0.0], dtype=np.float32)

@pytest.fixture()
def client():
    app = create_app({
        "TESTING": True,
        "SQLALCHEMY_DATABASE_URI": "sqlite://",
        "SECRET_KEY": "test-secret",
        "BOOTSTRAP_ADMIN_EMAIL": "admin@test.local",
        "BOOTSTRAP_ADMIN_PASSWORD": "test-password",
        "FACE_ENGINE": FakeEngine(),
        "FACE_DISTANCE_THRESHOLD": 0.85,
    })
    with app.test_client() as c:
        yield c
    with app.app_context():
        db.drop_all()

def login(client):
    return client.post("/api/login", json={"email":"admin@test.local","password":"test-password"})

def test_health(client):
    assert client.get("/health").json["status"] == "ok"

def test_login_and_student_creation(client):
    assert login(client).status_code == 200
    r = client.post("/api/students", json={"student_id":"S001","name":"Asha","department":"CSE"})
    assert r.status_code == 201
    assert r.json["student"]["name"] == "Asha"

def test_login_rejects_wrong_password(client):
    r = client.post("/api/login", json={"email":"admin@test.local","password":"wrong"})
    assert r.status_code == 401

def test_protected_endpoint(client):
    assert client.get("/api/students").status_code == 401

def test_duplicate_student_id(client):
    login(client)
    client.post("/api/students", json={"student_id":"S001","name":"Asha"})
    r = client.post("/api/students", json={"student_id":"S001","name":"Other"})
    assert r.status_code == 409

def test_session_creation(client):
    login(client)
    r = client.post("/api/sessions", json={"title":"AI lecture","subject":"AI"})
    assert r.status_code == 201
    assert r.json["session"]["is_open"] is True


def test_admin_can_create_faculty_and_list_users(client):
    assert login(client).status_code == 200
    created = client.post("/api/users", json={"email":"faculty@test.local", "password":"faculty-test-password", "role":"faculty"})
    assert created.status_code == 201
    assert created.json["user"]["role"] == "faculty"
    assert any(u["email"] == "faculty@test.local" for u in client.get("/api/users").json["users"])


def test_faculty_cannot_manage_users(client):
    assert login(client).status_code == 200
    client.post("/api/users", json={"email":"faculty@test.local", "password":"faculty-test-password", "role":"faculty"})
    client.post("/api/logout")
    assert client.post("/api/login", json={"email":"faculty@test.local", "password":"faculty-test-password"}).status_code == 200
    assert client.get("/api/users").status_code == 403


def test_short_password_rejected_for_new_user(client):
    assert login(client).status_code == 200
    r = client.post("/api/users", json={"email":"short@test.local", "password":"short", "role":"faculty"})
    assert r.status_code == 400


def test_attendance_is_deduplicated_per_session(client):
    import base64
    assert login(client).status_code == 200
    student = client.post("/api/students", json={"student_id":"S002", "name":"Demo Student"}).json["student"]
    sample = base64.b64encode(b"fake-image-bytes").decode()
    enrolled = client.post(f"/api/students/{student['id']}/enroll", json={"image_data": sample})
    assert enrolled.status_code == 200
    session_response = client.post("/api/sessions", json={"title":"Test class", "subject":"AI"})
    session_id = session_response.json["session"]["id"]
    first = client.post("/api/attendance/recognize", json={"image_data": sample, "session_id": session_id})
    second = client.post("/api/attendance/recognize", json={"image_data": sample, "session_id": session_id})
    assert first.status_code == 200 and first.json["matched"] is True
    assert first.json["duplicate"] is False
    assert second.status_code == 200 and second.json["duplicate"] is True
    assert client.get("/api/attendance").json["attendance"] and len(client.get("/api/attendance").json["attendance"]) == 1


def test_closed_session_rejects_attendance(client):
    import base64
    assert login(client).status_code == 200
    student = client.post("/api/students", json={"student_id":"S003", "name":"Demo Student"}).json["student"]
    sample = base64.b64encode(b"fake-image-bytes").decode()
    assert client.post(f"/api/students/{student['id']}/enroll", json={"image_data": sample}).status_code == 200
    session_id = client.post("/api/sessions", json={"title":"Closed class"}).json["session"]["id"]
    assert client.post(f"/api/sessions/{session_id}/close").status_code == 200
    result = client.post("/api/attendance/recognize", json={"image_data": sample, "session_id": session_id})
    assert result.status_code == 400


def test_analytics_includes_reports(client):
    assert login(client).status_code == 200
    data = client.get("/api/analytics").json
    assert "attendance_by_session" in data
    assert "daily_attendance_last_7_days" in data
    assert len(data["daily_attendance_last_7_days"]) == 7
