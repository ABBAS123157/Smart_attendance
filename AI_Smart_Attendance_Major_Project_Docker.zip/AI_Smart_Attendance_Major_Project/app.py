import os, io, csv, base64, secrets
from datetime import datetime, date, timezone, timedelta
from functools import wraps

import numpy as np
from flask import Flask, render_template, request, jsonify, redirect, url_for, session, send_file, flash
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import func, text
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

from ai_engine import FaceEngine, FaceEngineError

db = SQLAlchemy()
ALLOWED_IMAGE_TYPES = {"image/jpeg", "image/png", "image/webp"}
MAX_IMAGE_BYTES = 8 * 1024 * 1024

def create_app(test_config=None):
    app = Flask(__name__)
    database_url = os.getenv("DATABASE_URL", "sqlite:///attendance_dev.db")
    # Render and other providers may supply postgres:// or postgresql:// URLs.
    # The project installs psycopg v3, so select its SQLAlchemy dialect explicitly.
    if database_url.startswith("postgres://"):
        database_url = "postgresql+psycopg://" + database_url[len("postgres://"):]
    elif database_url.startswith("postgresql://"):
        database_url = "postgresql+psycopg://" + database_url[len("postgresql://"):]
    app.config.update(
        SECRET_KEY=os.getenv("SECRET_KEY", "dev-only-change-me"),
        SQLALCHEMY_DATABASE_URI=database_url,
        SQLALCHEMY_TRACK_MODIFICATIONS=False,
        MAX_CONTENT_LENGTH=MAX_IMAGE_BYTES,
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        SESSION_COOKIE_SECURE=os.getenv("COOKIE_SECURE", "false").lower() == "true",
        FACE_DISTANCE_THRESHOLD=float(os.getenv("FACE_DISTANCE_THRESHOLD", "0.85")),
        BOOTSTRAP_ADMIN_EMAIL=os.getenv("BOOTSTRAP_ADMIN_EMAIL", ""),
        BOOTSTRAP_ADMIN_PASSWORD=os.getenv("BOOTSTRAP_ADMIN_PASSWORD", ""),
        TESTING=False,
    )
    if test_config:
        app.config.update(test_config)
    db.init_app(app)

    with app.app_context():
        db.create_all()
        if app.config["BOOTSTRAP_ADMIN_EMAIL"] and app.config["BOOTSTRAP_ADMIN_PASSWORD"]:
            email = app.config["BOOTSTRAP_ADMIN_EMAIL"].strip().lower()
            if not User.query.filter_by(email=email).first():
                db.session.add(User(email=email, password_hash=generate_password_hash(app.config["BOOTSTRAP_ADMIN_PASSWORD"]), role="admin"))
                db.session.commit()

    engine = app.config.get("FACE_ENGINE") or FaceEngine()

    @app.get("/")
    def index():
        return render_template("index.html", logged_in=bool(session.get("user_id")), role=session.get("role"))

    @app.get("/health")
    def health():
        # A health response should verify database connectivity, not merely that Flask is alive.
        try:
            db.session.execute(text("SELECT 1"))
            return jsonify({"status": "ok", "database": "connected"})
        except Exception:
            db.session.rollback()
            app.logger.exception("Health check database query failed")
            return jsonify({"status": "degraded", "database": "unavailable"}), 503

    @app.post("/api/login")
    def login():
        payload = request.get_json(silent=True) or request.form
        email = str(payload.get("email", "")).strip().lower()
        password = str(payload.get("password", ""))
        user = User.query.filter_by(email=email).first()
        if not user or not check_password_hash(user.password_hash, password):
            return jsonify({"error": "Invalid email or password"}), 401
        session.clear()
        session["user_id"] = user.id
        session["role"] = user.role
        session["email"] = user.email
        return jsonify({"ok": True, "role": user.role, "email": user.email})

    @app.post("/api/logout")
    def logout():
        session.clear()
        return jsonify({"ok": True})

    def login_required(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            if not session.get("user_id"):
                return jsonify({"error": "Please sign in first"}), 401
            return fn(*args, **kwargs)
        return wrapper

    def role_required(*roles):
        def decorator(fn):
            @wraps(fn)
            def wrapper(*args, **kwargs):
                if not session.get("user_id"):
                    return jsonify({"error": "Please sign in first"}), 401
                if session.get("role") not in roles:
                    return jsonify({"error": "Insufficient permissions"}), 403
                return fn(*args, **kwargs)
            return wrapper
        return decorator

    @app.get("/api/users")
    @role_required("admin")
    def list_users():
        users = User.query.order_by(User.email).all()
        return jsonify({"users": [{"id": u.id, "email": u.email, "role": u.role} for u in users]})

    @app.post("/api/users")
    @role_required("admin")
    def create_user():
        payload = request.get_json(silent=True) or request.form
        email = str(payload.get("email", "")).strip().lower()
        password = str(payload.get("password", ""))
        role = str(payload.get("role", "faculty")).strip().lower()
        if not email or "@" not in email or len(email) > 255:
            return jsonify({"error": "Enter a valid email address."}), 400
        if len(password) < 12:
            return jsonify({"error": "Password must be at least 12 characters."}), 400
        if role not in {"admin", "faculty"}:
            return jsonify({"error": "Role must be admin or faculty."}), 400
        if User.query.filter_by(email=email).first():
            return jsonify({"error": "An account with that email already exists."}), 409
        user = User(email=email, password_hash=generate_password_hash(password), role=role)
        db.session.add(user)
        db.session.commit()
        return jsonify({"ok": True, "user": {"id": user.id, "email": user.email, "role": user.role}}), 201

    def image_from_request():
        if "image" in request.files:
            f = request.files["image"]
            if f.mimetype not in ALLOWED_IMAGE_TYPES:
                raise ValueError("Upload a JPG, PNG, or WebP image.")
            raw = f.read(MAX_IMAGE_BYTES + 1)
        else:
            payload = request.get_json(silent=True) or {}
            data = payload.get("image_data", "")
            if "," in data:
                data = data.split(",", 1)[1]
            try:
                raw = base64.b64decode(data, validate=True)
            except Exception:
                raise ValueError("Choose or capture an image first.")
        if not raw or len(raw) > MAX_IMAGE_BYTES:
            raise ValueError("Image is empty or larger than 8 MB.")
        return raw

    @app.post("/api/students")
    @role_required("admin", "faculty")
    def add_student():
        payload = request.get_json(silent=True) or request.form
        student_id = str(payload.get("student_id", "")).strip()
        name = str(payload.get("name", "")).strip()
        if not student_id or not name:
            return jsonify({"error": "Student ID and full name are required."}), 400
        if Student.query.filter_by(student_id=student_id).first():
            return jsonify({"error": "That student ID already exists."}), 409
        student = Student(student_id=student_id, name=name, department=str(payload.get("department", "")).strip())
        db.session.add(student)
        db.session.commit()
        return jsonify({"ok": True, "student": student.to_dict()}), 201

    @app.get("/api/students")
    @login_required
    def list_students():
        return jsonify({"students": [s.to_dict() for s in Student.query.order_by(Student.name).all()]})

    @app.post("/api/students/<int:student_pk>/enroll")
    @role_required("admin", "faculty")
    def enroll(student_pk):
        student = db.session.get(Student, student_pk)
        if not student:
            return jsonify({"error": "Student not found."}), 404
        try:
            raw = image_from_request()
            embedding = engine.embedding_from_bytes(raw)
        except (ValueError, FaceEngineError) as e:
            return jsonify({"error": str(e)}), 422
        student.embedding = embedding.tolist()
        student.enrolled_at = datetime.now(timezone.utc)
        db.session.commit()
        return jsonify({"ok": True, "message": "Face embedding saved. Delete source photos after enrollment; this app does not store the uploaded image."})

    @app.post("/api/attendance/recognize")
    @role_required("admin", "faculty")
    def recognize():
        # IMPORTANT: client blink challenge is a teaching prototype, not a trusted liveness assertion.
        try:
            raw = image_from_request()
            candidate = engine.embedding_from_bytes(raw)
        except (ValueError, FaceEngineError) as e:
            return jsonify({"error": str(e)}), 422

        enrolled = Student.query.filter(Student.embedding.isnot(None)).all()
        if not enrolled:
            return jsonify({"error": "No enrolled face templates yet."}), 400
        scored = []
        for student in enrolled:
            emb = np.asarray(student.embedding, dtype=np.float32)
            if emb.shape != candidate.shape:
                continue
            scored.append((float(np.linalg.norm(emb - candidate)), student))
        if not scored:
            return jsonify({"error": "No compatible face templates found."}), 500
        distance, match = min(scored, key=lambda x: x[0])
        if distance > app.config["FACE_DISTANCE_THRESHOLD"]:
            return jsonify({"matched": False, "message": "Unknown face — attendance not recorded.", "distance": round(distance, 4)}), 200

        session_id = request.form.get("session_id") or (request.get_json(silent=True) or {}).get("session_id")
        if not session_id:
            return jsonify({"error": "Select an attendance session."}), 400
        att_session = db.session.get(AttendanceSession, int(session_id)) if str(session_id).isdigit() else None
        if not att_session or not att_session.is_open:
            return jsonify({"error": "Session not found or closed."}), 400

        # Deduplicate by student + session.
        existing = Attendance.query.filter_by(student_id=match.id, session_id=att_session.id).first()
        if existing:
            return jsonify({"matched": True, "duplicate": True, "student": match.to_dict(), "message": "Already marked for this session.", "distance": round(distance, 4)})
        record = Attendance(student_id=match.id, session_id=att_session.id, status="present", confidence_distance=distance)
        db.session.add(record)
        db.session.commit()
        return jsonify({"matched": True, "duplicate": False, "student": match.to_dict(), "message": "Attendance marked.", "distance": round(distance, 4)})

    @app.post("/api/sessions")
    @role_required("admin", "faculty")
    def create_session():
        payload = request.get_json(silent=True) or request.form
        title = str(payload.get("title", "")).strip()
        if not title:
            return jsonify({"error": "Session title is required."}), 400
        s = AttendanceSession(title=title, subject=str(payload.get("subject", "")).strip(), is_open=True)
        db.session.add(s)
        db.session.commit()
        return jsonify({"session": s.to_dict()}), 201

    @app.get("/api/sessions")
    @login_required
    def list_sessions():
        return jsonify({"sessions": [s.to_dict() for s in AttendanceSession.query.order_by(AttendanceSession.created_at.desc()).all()]})

    @app.post("/api/sessions/<int:session_id>/close")
    @role_required("admin", "faculty")
    def close_session(session_id):
        s = db.session.get(AttendanceSession, session_id)
        if not s:
            return jsonify({"error": "Session not found."}), 404
        s.is_open = False
        db.session.commit()
        return jsonify({"ok": True, "session": s.to_dict()})

    @app.get("/api/attendance")
    @login_required
    def attendance_list():
        records = Attendance.query.join(Student).join(AttendanceSession).order_by(Attendance.marked_at.desc()).limit(500).all()
        return jsonify({"attendance": [r.to_dict() for r in records]})

    @app.get("/api/attendance.csv")
    @role_required("admin", "faculty")
    def attendance_csv():
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(["student_id", "student_name", "department", "session", "subject", "status", "marked_at_utc", "embedding_distance"])
        records = Attendance.query.join(Student).join(AttendanceSession).order_by(Attendance.marked_at.desc()).all()
        for r in records:
            writer.writerow([r.student.student_id, r.student.name, r.student.department, r.attendance_session.title, r.attendance_session.subject, r.status, r.marked_at.isoformat(), r.confidence_distance])
        mem = io.BytesIO(output.getvalue().encode("utf-8-sig"))
        mem.seek(0)
        return send_file(mem, mimetype="text/csv", as_attachment=True, download_name="attendance.csv")

    @app.get("/api/analytics")
    @login_required
    def analytics():
        total_students = Student.query.count()
        enrolled = Student.query.filter(Student.embedding.isnot(None)).count()
        total_records = Attendance.query.count()
        by_session = db.session.query(
            AttendanceSession.id, AttendanceSession.title, AttendanceSession.subject,
            func.count(Attendance.id).label("present_count")
        ).outerjoin(Attendance, Attendance.session_id == AttendanceSession.id).group_by(
            AttendanceSession.id, AttendanceSession.title, AttendanceSession.subject
        ).order_by(AttendanceSession.created_at.desc()).limit(50).all()
        seven_days_ago = datetime.now(timezone.utc) - timedelta(days=6)
        recent = Attendance.query.filter(Attendance.marked_at >= seven_days_ago).all()
        daily = {}
        for record in recent:
            key = record.marked_at.date().isoformat()
            daily[key] = daily.get(key, 0) + 1
        for offset in range(7):
            key = (date.today() - timedelta(days=6-offset)).isoformat()
            daily.setdefault(key, 0)
        return jsonify({
            "students": total_students,
            "enrolled": enrolled,
            "attendance_records": total_records,
            "open_sessions": AttendanceSession.query.filter_by(is_open=True).count(),
            "attendance_by_session": [
                {"session_id": row.id, "title": row.title, "subject": row.subject or "", "present_count": row.present_count}
                for row in by_session
            ],
            "daily_attendance_last_7_days": [{"date": key, "count": daily[key]} for key in sorted(daily)]
        })

    @app.get("/api/reports/summary")
    @login_required
    def report_summary():
        # JSON summary suitable for project demonstrations and report screenshots.
        response = analytics()
        return response

    @app.errorhandler(413)
    def too_large(_):
        return jsonify({"error": "Image too large. Maximum size is 8 MB."}), 413

    return app

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(255), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), nullable=False, default="faculty")

class Student(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.String(80), unique=True, nullable=False, index=True)
    name = db.Column(db.String(160), nullable=False)
    department = db.Column(db.String(120), default="")
    embedding = db.Column(db.JSON, nullable=True)
    enrolled_at = db.Column(db.DateTime(timezone=True), nullable=True)
    def to_dict(self):
        return {"id": self.id, "student_id": self.student_id, "name": self.name, "department": self.department, "enrolled": self.embedding is not None}

class AttendanceSession(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(180), nullable=False)
    subject = db.Column(db.String(120), default="")
    is_open = db.Column(db.Boolean, nullable=False, default=True)
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc))
    def to_dict(self):
        return {"id": self.id, "title": self.title, "subject": self.subject, "is_open": self.is_open, "created_at": self.created_at.isoformat()}

class Attendance(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey("student.id"), nullable=False)
    session_id = db.Column(db.Integer, db.ForeignKey("attendance_session.id"), nullable=False)
    status = db.Column(db.String(20), nullable=False, default="present")
    marked_at = db.Column(db.DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc))
    confidence_distance = db.Column(db.Float, nullable=True)
    student = db.relationship("Student")
    attendance_session = db.relationship("AttendanceSession")
    __table_args__ = (db.UniqueConstraint("student_id", "session_id", name="uq_attendance_student_session"),)
    def to_dict(self):
        return {"id": self.id, "student_id": self.student.student_id, "student_name": self.student.name,
                "session": self.attendance_session.title, "subject": self.attendance_session.subject,
                "status": self.status, "marked_at": self.marked_at.isoformat(), "distance": self.confidence_distance}

app = create_app()

if __name__ == "__main__":
    # For local development only. Production uses Gunicorn.
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "5000")), debug=False)
