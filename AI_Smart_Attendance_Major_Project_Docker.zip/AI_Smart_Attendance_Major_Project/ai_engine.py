"""CPU-friendly FaceNet embedding adapter. Model weights are downloaded on first use.
The first request can be slow and needs internet access. Validate thresholds on your dataset.
"""
import io
import numpy as np
from PIL import Image, ImageOps
from ai_engine_base import FaceEngineError

class FaceEngine:
    def __init__(self):
        self._model = None
        self._mtcnn = None

    def _load(self):
        if self._model is not None:
            return
        try:
            import torch
            from facenet_pytorch import InceptionResnetV1, MTCNN
            self._mtcnn = MTCNN(image_size=160, margin=20, post_process=True, device="cpu")
            self._model = InceptionResnetV1(pretrained="vggface2").eval()
        except Exception as exc:
            raise FaceEngineError(
                "Deep-learning model is not ready. Install requirements and allow the first-run model download. "
                f"Details: {type(exc).__name__}: {exc}"
            )

    def embedding_from_bytes(self, raw: bytes) -> np.ndarray:
        self._load()
        try:
            image = Image.open(io.BytesIO(raw))
            image = ImageOps.exif_transpose(image).convert("RGB")
        except Exception:
            raise FaceEngineError("The uploaded file is not a valid image.")
        face = self._mtcnn(image)
        if face is None:
            raise FaceEngineError("No clear face detected. Face the camera, improve lighting, and try again.")
        import torch
        with torch.no_grad():
            emb = self._model(face.unsqueeze(0)).squeeze(0).cpu().numpy().astype(np.float32)
        norm = np.linalg.norm(emb)
        if not np.isfinite(norm) or norm == 0:
            raise FaceEngineError("Could not calculate a valid face embedding.")
        return emb / norm
