# AI-Based Smart Attendance Management System — Major Project

## What is included
- Flask web app with PostgreSQL-ready SQLAlchemy data layer.
- FaceNet (`facenet-pytorch` InceptionResnetV1 pretrained on VGGFace2) embeddings for face enrollment and nearest-template matching.
- Student registry, admin/faculty role-based login, admin-only account provisioning, class sessions, duplicate attendance prevention, CSV export, per-session summaries and seven-day analytics.
- Responsive mobile UI with Android camera capture over HTTPS.
- Browser MediaPipe blink challenge **prototype only**.
- API tests for authentication/authorization, user provisioning, student creation, sessions, attendance deduplication, closed-session handling, and analytics; plus a legacy SQLite export helper.

## Important status and limitations
This is a runnable **project starter**, not a certified biometric attendance product. The model weights download at first inference; allow internet access and expect a slow first request. Threshold `0.85` is a starting value only and must be calibrated using your own validation set. The blink challenge is client-side and can be bypassed by a technically capable attacker; it is not secure anti-spoofing. Do not use for consequential decisions until independently tested for false accepts/rejects, demographic performance, spoof attacks, privacy, and security. A production system should verify a server-generated nonce and perform robust server-side liveness using a validated model or dedicated hardware.

The included tests use a fake deterministic embedding engine to test API flows. They **do not measure or validate face-recognition accuracy**.

## Local setup (computer)
Use Python 3.11.9. Install PostgreSQL 15+ and create a database/user:
```sql
CREATE USER attendance_user WITH PASSWORD 'choose-a-strong-password';
CREATE DATABASE smart_attendance OWNER attendance_user;
```
Then in a terminal:
```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
```
Copy `.env.example` to `.env` and edit the values. Export the variables in your shell (Flask does not automatically load `.env` in this starter):
```bash
# macOS/Linux example
export SECRET_KEY='a-long-random-secret'
export DATABASE_URL='postgresql+psycopg://attendance_user:YOUR_PASSWORD@localhost:5432/smart_attendance'
export BOOTSTRAP_ADMIN_EMAIL='admin@example.edu'
export BOOTSTRAP_ADMIN_PASSWORD='Use-a-long-unique-password'
export COOKIE_SECURE=false
python app.py
```
Windows PowerShell:
```powershell
$env:SECRET_KEY="a-long-random-secret"
$env:DATABASE_URL="postgresql+psycopg://attendance_user:YOUR_PASSWORD@localhost:5432/smart_attendance"
$env:BOOTSTRAP_ADMIN_EMAIL="admin@example.edu"
$env:BOOTSTRAP_ADMIN_PASSWORD="Use-a-long-unique-password"
$env:COOKIE_SECURE="false"
python app.py
```
Open `http://127.0.0.1:5000`. Database tables are created on startup. For an initial demo, create one admin using environment variables, sign in, create a student and a session, start the camera, select the student and enroll, then run blink challenge and mark attendance.

### Face model first run
The first enrollment request downloads FaceNet weights via `facenet-pytorch`/PyTorch. The server needs outbound internet access and disk space. On low-memory free hosting, the model may exceed the instance memory; test the actual chosen plan. If `torch` installation fails, use the package's official CPU install selector and matching PyTorch wheel versions, then install the remaining requirements.

## Online HTTPS deployment (Render + managed PostgreSQL)
1. Put this project in a Git repository and push it to GitHub. Do not commit `.env`, secrets, student data, photos, or model weights.
2. Create a managed PostgreSQL database in Render (or another provider). Copy its **internal** connection string if the web service is in the same provider/region. SQLAlchemy URL must use `postgresql+psycopg://...`; if provider gives `postgres://`, the app normalizes it.
3. Create a Render Web Service from the repository. Render can use `render.yaml`; alternatively set build command `pip install -r requirements.txt`, start command `gunicorn app:app --workers 1 --threads 4 --timeout 120`, health path `/health`.
4. Set environment variables: `DATABASE_URL`, `SECRET_KEY` (random), `BOOTSTRAP_ADMIN_EMAIL`, `BOOTSTRAP_ADMIN_PASSWORD`, `COOKIE_SECURE=true`, `FACE_DISTANCE_THRESHOLD=0.85`. Do not set real credentials in source control.
5. Deploy and wait for `/health` to return `{"status":"ok","database":"connected"}`. Check provider logs for model-download or memory failures. Use a paid/adequate memory instance if free tier is insufficient; free tiers and persistent disk/CPU availability change over time.
6. Open the HTTPS URL on Android Chrome, allow camera access, and use the front camera. Browser camera APIs normally require HTTPS (or localhost). If CDN scripts are blocked, the blink demo will not load; model inference itself runs on the server.
7. Test with consenting participants only. Never use real student images without written institutional approval and clear consent. Configure retention, access control, backups, and deletion procedures before any real deployment.

## Migration from the earlier SQLite/LBPH project
1. Stop the old app and make a **copy** of the old SQLite database; keep the original unchanged.
2. In the old project, identify the actual database filename and tables. Run:
   `python scripts/migrate_legacy_sqlite.py path/to/COPY_OF_OLD.db --out legacy_export`
3. Inspect the CSVs. This helper exports raw tables only; it does not guess old schema names or automatically insert rows into PostgreSQL.
4. Create PostgreSQL database and set `DATABASE_URL` as above. Start the new app; it creates the new schema.
5. Manually map old student IDs/names/departments into the new `Student` table and old attendance records into `AttendanceSession` + `Attendance`. Use a one-off import script after inspecting the real old schema; verify row counts and duplicates before accepting the import.
6. Re-enroll each student with new face images. LBPH/OpenCV face data is **not compatible** with FaceNet embeddings. Do not attempt to copy old LBPH `.yml` recognizer data into the new model.
7. Compare old and new records, keep a dated backup, and only switch users after a successful rehearsal.

## Dataset and evaluation plan
- Get written permission from your institution and each participant; document purpose, retention, opt-out, deletion, access, and who can see biometric templates.
- Target 30–100 consenting volunteers for a student project (or a smaller pilot if necessary), with 5–10 images per person across distance, lighting, glasses, and head pose. Enroll on a subset; hold out separate captures for testing. Do not split near-identical frames from the same video across train/test.
- Include a separate set of unknown/non-enrolled people. For liveness evaluation, record consented live captures and controlled print/photo replay and screen replay attempts; do not treat this basic blink script as a secure detector.
- Suggested protocol: per identity use 3–5 enrollment images and at least 5 separate probe images; record genuine and impostor comparisons. Select threshold on a validation split, then report metrics on a held-out test split.
- Report: rank-1 identification rate, false acceptance rate (FAR), false rejection rate (FRR), EER if calculable, unknown-person rejection, liveness attack acceptance rate, latency, and results by lighting/pose. Include confidence intervals and sample counts. Do not claim accuracy until measured.
- Keep raw images in a restricted, encrypted location and delete them according to the consent agreement. Prefer retaining embeddings only where permitted; embeddings are still sensitive biometric data.

## Tests
Install dependencies then run:
```bash
pytest -q
```
The included tests cover health endpoint, login, authorization, admin user provisioning, password policy, duplicate student IDs, session creation, attendance deduplication, closed-session rejection, and analytics. They use a fake engine, so do not interpret them as model validation. They use a fake engine, so do not interpret them as model validation. After deployment, also test: no face, multiple faces, blurry image, unknown person, duplicate attendance, closed session, poor light, photo replay, Android browser permission denial, and database restart/backup restoration.

## API overview
- `GET /api/users` and `POST /api/users` (admin only; create admin/faculty accounts with passwords of at least 12 characters)
- `GET /api/reports/summary` (signed-in summary JSON)
- `POST /api/login`
- `POST /api/logout`
- `POST /api/students` (admin/faculty)
- `GET /api/students` (signed in)
- `POST /api/students/<id>/enroll` (admin/faculty; image upload or `image_data` data URL JSON)
- `POST /api/sessions` / `GET /api/sessions` / `POST /api/sessions/<id>/close`
- `POST /api/attendance/recognize` (admin/faculty; image data URL + `session_id`)
- `GET /api/attendance`, `GET /api/attendance.csv`, `GET /api/analytics`
- `GET /health`

## Features that require additional validation
- **Recognition quality:** threshold `0.85` is not calibrated; measure FAR/FRR and unknown-person rejection on a held-out, consented dataset before relying on it.
- **Liveness:** blink detection runs in the browser and its result is not cryptographically attested by the server. It can be bypassed and must be treated as a demonstration only.
- **Mobile/browser:** camera behavior depends on Android Chrome permissions, HTTPS, device camera availability, and third-party MediaPipe CDN access. Test on the actual target phone.
- **Hosting:** model weights download on first inference and PyTorch consumes significant RAM/disk. Successful deployment cannot be guaranteed on low-memory/free plans without a real deployment test.
- **Data migration:** the included legacy helper exports SQLite tables; it does not automatically map arbitrary old schemas or convert LBPH data into FaceNet embeddings.

## Security and production hardening still required
- CSRF protection for cookie-authenticated POST routes, login rate limiting, audit logs, account-management UI, password reset, faculty-to-class authorization, and session expiry policy.
- Robust server-side liveness challenge verification, anti-replay, secure camera capture, threshold calibration, demographic/fairness testing.
- Database migrations with Alembic (current schema uses `create_all`, suitable only for fresh/student demos).
- HTTPS is provided by the hosting platform; enforce secure cookies and use secret management.
- Legal/institutional privacy review and data deletion workflow.

## Run with Docker (recommended for consistent setup)

### Requirements

Install Docker Desktop (Windows/macOS) or Docker Engine + the Docker Compose plugin (Linux). The first image build downloads Python packages, and the first face-recognition request downloads FaceNet model weights; internet access is needed for those first-time steps. CPU inference is used.

### Start on your computer

1. Open a terminal in the project folder (the folder containing `Dockerfile`).
2. Copy `.env.docker.example` to `.env`.
   - Windows PowerShell: `Copy-Item .env.docker.example .env`
   - macOS/Linux: `cp .env.docker.example .env`
3. Edit `.env`. Replace the database password, secret key, and admin password with strong unique values. Do not share or commit `.env`.
4. Build and start both the web app and PostgreSQL:
   ```bash
   docker compose up --build -d
   ```
5. Check status and logs:
   ```bash
   docker compose ps
   docker compose logs -f web
   ```
6. Open `http://localhost:5000` on the computer. Health check: `http://localhost:5000/health`.
7. Sign in using `BOOTSTRAP_ADMIN_EMAIL` and `BOOTSTRAP_ADMIN_PASSWORD` from `.env`.

To stop containers without deleting saved data: `docker compose down`. To stop and **delete the database and model cache volumes**, use `docker compose down -v` (destructive; do not run unless you intend to erase them).

### Open on Android on the same Wi-Fi

1. Keep the computer and Android phone on the same Wi-Fi network.
2. Find the computer's local IP address (Windows: `ipconfig`; macOS/Linux: `ip addr` or network settings).
3. On Android, open `http://COMPUTER_LOCAL_IP:5000`, replacing the example with the computer's actual IP.
4. Allow the OS firewall to accept inbound connections on port 5000 only on your trusted private network.

**Camera limitation:** browsers generally require a secure context (HTTPS) for camera access, except for localhost. Opening the site by a computer's local IP over plain HTTP may prevent camera access. For camera use on Android, deploy behind HTTPS or use a trusted HTTPS tunnel. Do not expose this development Compose setup directly to the public internet.

### Useful Docker commands

```bash
docker compose logs -f web       # application logs
docker compose logs -f db        # PostgreSQL logs
docker compose restart web       # restart app
docker compose down              # stop containers; keep named volumes
docker compose up --build -d    # rebuild after code changes
```

### Deployment notes

Use a production HTTPS reverse proxy or a hosting platform that terminates TLS before setting `COOKIE_SECURE=true`. Keep `.env` secret, back up PostgreSQL, and validate FaceNet thresholds and liveness detection with a consented test dataset before real-world use. The current browser blink challenge is a prototype, not strong anti-spoofing security. The FaceNet weights are cached in the named `model_cache` volume after first download.
