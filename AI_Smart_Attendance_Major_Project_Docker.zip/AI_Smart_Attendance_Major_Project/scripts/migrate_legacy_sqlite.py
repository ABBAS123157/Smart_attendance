"""Export legacy SQLite student and attendance data for review.
Run this script against a COPY of the old database, never the only original.
Legacy face-recognition models/encodings are not portable to FaceNet embeddings.
"""
import argparse, sqlite3, csv, os

def main():
    p=argparse.ArgumentParser()
    p.add_argument("database", help="Path to copied legacy SQLite database")
    p.add_argument("--out", default="legacy_export")
    args=p.parse_args()
    os.makedirs(args.out, exist_ok=True)
    con=sqlite3.connect(args.database); con.row_factory=sqlite3.Row
    tables={r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    print("Tables found:", sorted(tables))
    for table in sorted(tables):
        if table.startswith("sqlite_"): continue
        try:
            rows=con.execute(f'SELECT * FROM "{table}"').fetchall()
            if not rows: continue
            path=os.path.join(args.out, f"{table}.csv")
            with open(path,"w",newline="",encoding="utf-8-sig") as f:
                writer=csv.writer(f); writer.writerow(rows[0].keys())
                writer.writerows([tuple(r) for r in rows])
            print(f"Exported {len(rows)} rows -> {path}")
        except sqlite3.Error as e:
            print(f"Skipped {table}: {e}")
    con.close()
    print("Review CSVs and map columns manually to the new schema. Do not import legacy face encodings.")
if __name__=="__main__": main()
