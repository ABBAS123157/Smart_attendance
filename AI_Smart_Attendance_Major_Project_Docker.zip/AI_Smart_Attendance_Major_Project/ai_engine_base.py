class FaceEngineError(Exception):
    """Safe-to-display inference error."""
