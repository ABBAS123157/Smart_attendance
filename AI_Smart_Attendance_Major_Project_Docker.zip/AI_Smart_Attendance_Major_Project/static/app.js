const $ = id => document.getElementById(id);
let students = [], sessions = [], selectedStudent = null, cameraStream = null, blinkDetected = false;
let faceMesh = null, cameraLoop = null, eyeClosed = false, blinkCount = 0, challengeRunning = false;

async function api(path, options={}) {
  const response = await fetch(path, {credentials:"same-origin", ...options});
  const type = response.headers.get("content-type") || "";
  const data = type.includes("application/json") ? await response.json() : null;
  if (!response.ok) throw new Error(data?.error || `Request failed (${response.status})`);
  return data;
}
function json(body){return {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)}}
function msg(id, text){$(id).textContent = text}
function loggedInUI(email="Signed in"){ $("authStatus").textContent=email; $("loginBtn").classList.add("hidden"); $("logoutBtn").classList.remove("hidden"); }
function loggedOutUI(){ $("authStatus").textContent="Signed out"; $("loginBtn").classList.remove("hidden"); $("logoutBtn").classList.add("hidden"); }

$("loginBtn").onclick = async () => {
  try { const d=await api("/api/login",json({email:$("email").value,password:$("password").value})); loggedInUI(d.email); msg("loginMsg","Signed in successfully."); await refreshAll(); }
  catch(e){msg("loginMsg",e.message)}
};
$("logoutBtn").onclick = async () => { try{await api("/api/logout",{method:"POST"});loggedOutUI();msg("loginMsg","Signed out.");}catch(e){msg("loginMsg",e.message)} };
$("refreshBtn").onclick = refreshAll;
async function refreshAll(){
  try{
    const [a,s,se]=await Promise.all([api("/api/analytics"),api("/api/students"),api("/api/sessions")]);
    $("statStudents").textContent=a.students; $("statEnrolled").textContent=a.enrolled; $("statAttendance").textContent=a.attendance_records;
    students=s.students;sessions=se.sessions; renderStudents(); renderSessions();
  }catch(e){msg("loginMsg",e.message)}
}
function renderStudents(){
  const root=$("studentList");root.innerHTML="";
  if(!students.length){root.textContent="No students registered yet.";return}
  students.forEach(st=>{
    const row=document.createElement("div");row.className="student";
    const info=document.createElement("div");info.innerHTML=`<b></b><small></small>`;info.querySelector("b").textContent=`${st.student_id} · ${st.name}`;info.querySelector("small").textContent=`${st.department||"No department"} · ${st.enrolled?"Face enrolled":"Not enrolled"}`;
    const btn=document.createElement("button");btn.className="secondary";btn.textContent=st.enrolled?"Re-enroll":"Select for enrollment";btn.onclick=()=>{selectedStudent=st;msg("studentMsg",`Selected ${st.name}. Start camera and capture enrollment image.`);$("captureEnrollBtn").disabled=!cameraStream;};
    row.append(info,btn);root.append(row);
  });
}
function renderSessions(){
  const sel=$("sessionSelect"),previous=sel.value;sel.innerHTML='<option value="">Choose an open session</option>';
  sessions.filter(s=>s.is_open).forEach(s=>{const o=document.createElement("option");o.value=s.id;o.textContent=`${s.title}${s.subject?" — "+s.subject:""}`;sel.append(o)});
  if(previous)sel.value=previous;
}
$("addStudentBtn").onclick=async()=>{
 try{const d=await api("/api/students",json({student_id:$("studentId").value,name:$("studentName").value,department:$("department").value}));msg("studentMsg",`Added ${d.student.name}.`);$("studentId").value="";$("studentName").value="";$("department").value="";await refreshAll();}
 catch(e){msg("studentMsg",e.message)}
};
$("createSessionBtn").onclick=async()=>{
 try{await api("/api/sessions",json({title:$("sessionTitle").value,subject:$("sessionSubject").value}));msg("sessionMsg","Session created.");$("sessionTitle").value="";$("sessionSubject").value="";await refreshAll();}
 catch(e){msg("sessionMsg",e.message)}
};
$("closeSessionBtn").onclick=async()=>{
 if(!$("sessionSelect").value){msg("sessionMsg","Select a session first.");return}
 try{await api(`/api/sessions/${$("sessionSelect").value}/close`,{method:"POST"});msg("sessionMsg","Session closed.");await refreshAll();}
 catch(e){msg("sessionMsg",e.message)}
};
$("startCameraBtn").onclick=async()=>{
 try{
  cameraStream=await navigator.mediaDevices.getUserMedia({video:{facingMode:"user",width:{ideal:640},height:{ideal:480}},audio:false});
  $("video").srcObject=cameraStream; await $("video").play();
  $("challengeBtn").disabled=false;$("captureEnrollBtn").disabled=!selectedStudent;$("markAttendanceBtn").disabled=false;
  msg("cameraMsg","Camera ready. Use the blink challenge before attendance capture.");
  $("livenessStatus").textContent="Camera active. Start the blink challenge.";
 }catch(e){msg("cameraMsg","Camera unavailable. Open this website over HTTPS, allow camera permission, and try again. "+e.message)}
};
$("challengeBtn").onclick=async()=>{
 if(!cameraStream){msg("cameraMsg","Start camera first.");return}
 try{
  if(typeof FaceMesh==="undefined"){msg("cameraMsg","MediaPipe did not load. Check internet access and reload.");return}
  challengeRunning=true;blinkDetected=false;blinkCount=0;eyeClosed=false;
  $("challengeBtn").disabled=true;$("livenessStatus").textContent="Liveness demo: blink naturally once.";
  faceMesh=new FaceMesh({locateFile:(file)=>`https://cdn.jsdelivr.net/npm/@mediapipe/face_mesh/${file}`});
  faceMesh.setOptions({maxNumFaces:1,refineLandmarks:true,minDetectionConfidence:.6,minTrackingConfidence:.6});
  faceMesh.onResults(results=>{
   if(!challengeRunning)return;
   const lm=results.multiFaceLandmarks?.[0];
   if(!lm){$("livenessStatus").textContent="No face found — center your face in the frame.";return}
   // Approximate eye aspect ratio using FaceMesh landmarks. This is not anti-spoofing.
   const ear=(a,b,c,d,e,f)=> (Math.hypot(lm[b].x-lm[f].x,lm[b].y-lm[f].y)+Math.hypot(lm[c].x-lm[e].x,lm[c].y-lm[e].y))/(2*Math.hypot(lm[a].x-lm[d].x,lm[a].y-lm[d].y));
   const left=ear(33,160,158,133,153,144),right=ear(362,385,387,263,373,380),avg=(left+right)/2;
   if(avg<.19)eyeClosed=true;
   if(eyeClosed&&avg>.23){blinkCount++;eyeClosed=false;if(blinkCount>=1){blinkDetected=true;challengeRunning=false;$("livenessStatus").textContent="Blink observed in browser demo. Capture promptly."; $("challengeBtn").disabled=false;}}
  });
  const detect=async()=>{if(!challengeRunning)return;await faceMesh.send({image:$("video")});requestAnimationFrame(detect)};
  detect();
  setTimeout(()=>{if(challengeRunning){challengeRunning=false;$("challengeBtn").disabled=false;$("livenessStatus").textContent="Challenge timed out. Try again with better lighting."; }},15000);
 }catch(e){challengeRunning=false;$("challengeBtn").disabled=false;msg("cameraMsg","Liveness demo error: "+e.message)}
};
function snapshotDataURL(){const v=$("video"),c=$("captureCanvas");if(!v.videoWidth)throw new Error("Camera frame not ready.");c.width=v.videoWidth;c.height=v.videoHeight;c.getContext("2d").drawImage(v,0,0,c.width,c.height);return c.toDataURL("image/jpeg",.9)}
async function uploadSnapshot(url, extra={}){
 const data=snapshotDataURL();return api(url,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({image_data:data,...extra})});
}
$("captureEnrollBtn").onclick=async()=>{
 if(!selectedStudent){msg("cameraMsg","Select a student in the registry first.");return}
 try{const d=await uploadSnapshot(`/api/students/${selectedStudent.id}/enroll`);msg("cameraMsg",d.message);await refreshAll();}
 catch(e){msg("cameraMsg",e.message)}
};
$("markAttendanceBtn").onclick=async()=>{
 if(!blinkDetected){msg("cameraMsg","Run the browser blink challenge first. This is only a basic demonstration.");return}
 if(!$("sessionSelect").value){msg("cameraMsg","Select an open attendance session first.");return}
 try{const d=await uploadSnapshot("/api/attendance/recognize",{session_id:$("sessionSelect").value});msg("cameraMsg",d.message||d.error||"Complete.");blinkDetected=false;await loadAttendance();await refreshAll();}
 catch(e){msg("cameraMsg",e.message)}
};
$("loadAttendanceBtn").onclick=loadAttendance;
async function loadAttendance(){
 try{const d=await api("/api/attendance"),root=$("attendanceRows");root.innerHTML="";
 if(!d.attendance.length){root.innerHTML='<tr><td colspan="5">No attendance records yet.</td></tr>';return}
 d.attendance.forEach(r=>{const tr=document.createElement("tr");[`${r.student_id} · ${r.student_name}`,r.session,r.subject,r.status,new Date(r.marked_at).toLocaleString()].forEach(v=>{const td=document.createElement("td");td.textContent=v;tr.append(td)});root.append(tr)})
 }catch(e){msg("cameraMsg",e.message)}
}
$("exportBtn").onclick=()=>{window.location.href="/api/attendance.csv"};
// Attempt to refresh if a prior session cookie is still valid.
window.addEventListener("load",()=>{refreshAll().catch(()=>{});});
