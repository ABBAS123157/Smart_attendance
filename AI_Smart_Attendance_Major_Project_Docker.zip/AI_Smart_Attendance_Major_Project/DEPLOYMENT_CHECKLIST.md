# Pre-deployment checklist

- [ ] Rotate `SECRET_KEY`; set strong admin password in host secret settings.
- [ ] PostgreSQL URL points to managed database; verify backup/restore.
- [ ] `COOKIE_SECURE=true` on HTTPS host.
- [ ] Check `/health` and inspect server logs.
- [ ] Test model download, RAM usage, and latency on actual hosting plan.
- [ ] Calibrate threshold with a validation set; do not assume 0.85 is correct.
- [ ] Confirm consent, institutional approval, retention/deletion, and manual alternative.
- [ ] Validate Android Chrome camera permissions and MediaPipe CDN loading.
- [ ] Do not treat the blink challenge as secure liveness.
- [ ] Add CSRF protection, rate limiting, audit logs, and robust server-side liveness before real deployment.

- [ ] Test `/api/users` as admin and confirm faculty receives HTTP 403.
- [ ] Test `/api/analytics`, `/api/reports/summary`, and `/api/attendance.csv`; reconcile totals against database records.
- [ ] Run `python -m pytest -q` after installing project dependencies.
- [ ] Confirm `gunicorn` exists in requirements and `app.py` exports `app`.
- [ ] Confirm `/health` reports a database connection and returns HTTP 503 if PostgreSQL is unavailable.

## Docker checklist

- [ ] Install Docker and Docker Compose.
- [ ] Copy `.env.docker.example` to `.env` and replace every placeholder secret.
- [ ] Run `docker compose up --build -d`.
- [ ] Verify `docker compose ps` shows the database healthy and web running.
- [ ] Verify `http://localhost:5000/health` returns `{"status":"ok","database":"connected"}`.
- [ ] Verify administrator login and student/faculty workflows.
- [ ] For Android camera access, use an HTTPS deployment; plain HTTP via local IP may not permit camera access.
- [ ] Configure HTTPS, backups, secret management, monitoring, and access restrictions before any public deployment.
